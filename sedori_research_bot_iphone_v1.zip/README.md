# せどりリサーチBot V1

## できること
- ブラウザで「利益商品を探す」
- 最低利益・最低利益率を設定
- デモモードで即動作
- 楽天市場API / Yahoo!ショッピングAPIの検索アダプタを搭載
- 商品URLをクリック
- 利益・利益率・手数料・送料の計算
- 販売アドバイス表示

## 起動
Python 3.11+ 推奨。

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

ブラウザで http://127.0.0.1:8000

## APIキー
`.env` に楽天・Yahoo!の認証情報を入れるとライブ検索アダプタが有効になります。

## 重要
V1では、デモ商品について利益計算まで完全に動きます。
楽天/Yahoo!のライブ検索結果は「仕入れ候補」として取得しますが、販売側の価格データを勝手にスクレイピングして利益を捏造しない設計です。

本番版では、販売側の公式API・許諾済みデータソースを追加して、
「同一商品の照合 → 販売価格 → 手数料 → 送料 → 利益 → ランキング」
まで完成させます。


## iPhone向け
この版はiPhoneの縦画面を優先したUIです。
サーバーを外部公開するとSafariからアクセスできます。
manifest.webmanifestも同梱しているので、HTTPS環境では「ホーム画面に追加」でアプリ風に利用できます。

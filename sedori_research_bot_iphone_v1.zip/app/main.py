import os, math
from urllib.parse import quote_plus
from fastapi import FastAPI, Request, Query
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
import httpx
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="せどりリサーチBot V1")
templates = Jinja2Templates(directory="app/templates")

DEMO = [
    {"name":"ワイヤレスイヤホン Example X","buy":3980,"sell":7980,"url":"https://example.com/buy/1","source":"Demo"},
    {"name":"ゲームソフト Example 2026","buy":2480,"sell":5480,"url":"https://example.com/buy/2","source":"Demo"},
    {"name":"小型家電 Example Mini","buy":5200,"sell":9800,"url":"https://example.com/buy/3","source":"Demo"},
    {"name":"ホビー Example Figure","buy":6800,"sell":11800,"url":"https://example.com/buy/4","source":"Demo"},
]

def calc(item, fee_rate=0.10, shipping=750):
    buy = int(item["buy"])
    sell = int(item["sell"])
    fee = math.floor(sell * fee_rate)
    profit = sell - buy - fee - shipping
    margin = (profit / sell * 100) if sell else 0
    score = 5 if margin >= 30 and profit >= 3000 else 4 if margin >= 20 and profit >= 2000 else 3 if profit >= 1000 else 2
    item.update({"fee":fee, "shipping":shipping, "profit":profit, "margin":round(margin,1), "score":score})
    return item

async def rakuten_search(keyword, hits=10):
    appid = os.getenv("RAKUTEN_APPLICATION_ID")
    key = os.getenv("RAKUTEN_ACCESS_KEY")
    if not appid or not key:
        return []
    url = "https://openapi.rakuten.co.jp/ichibams/api/IchibaItem/Search/20260701"
    params = {
        "applicationId": appid, "accessKey": key, "keyword": keyword,
        "format":"json", "formatVersion":2, "hits":hits,
        "elements":"itemName,itemPrice,itemUrl,itemCode,janCode"
    }
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        data = r.json()
    out=[]
    for x in data.get("items", []):
        out.append({
            "name": x.get("itemName",""),
            "buy": int(x.get("itemPrice") or 0),
            "sell": 0,
            "url": x.get("itemUrl",""),
            "source":"Rakuten",
            "jan": x.get("janCode")
        })
    return out

async def yahoo_search(keyword, hits=10):
    appid = os.getenv("YAHOO_APP_ID")
    if not appid:
        return []
    url = "https://shopping.yahooapis.jp/ShoppingWebService/V3/itemSearch"
    params = {"appid":appid, "query":keyword, "hits":hits, "sort":"+price"}
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        data = r.json()
    out=[]
    for x in data.get("hits", []):
        out.append({
            "name": x.get("name",""),
            "buy": int(x.get("price") or 0),
            "sell": 0,
            "url": (x.get("url") or {}).get("pc",""),
            "source":"Yahoo!ショッピング",
            "jan": x.get("janCode")
        })
    return out

async def search_all(keyword):
    results=[]
    # V1: live source adapters are independent; missing credentials are skipped.
    for fn in (rakuten_search, yahoo_search):
        try:
            results.extend(await fn(keyword, 10))
        except Exception as e:
            print("source error:", fn.__name__, e)
    if not results:
        results = [dict(x) for x in DEMO]
    return results

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request":request})

@app.get("/api/search")
async def api_search(
    keyword: str = Query("", max_length=100),
    min_profit: int = Query(2000, ge=0, le=1000000),
    min_margin: float = Query(20, ge=0, le=100),
    shipping: int = Query(None, ge=0, le=100000),
):
    shipping = shipping if shipping is not None else int(os.getenv("DEFAULT_SHIPPING","750"))
    fee_rate = float(os.getenv("DEFAULT_SELLING_FEE_RATE","0.10"))
    items = await search_all(keyword.strip() or "人気商品")
    # Demo/live source items only have purchase price. For V1 demo we already have sell prices.
    # A production build should add a permitted sales-price adapter here.
    scored=[]
    for item in items:
        if not item.get("sell"):
            # Keep live search items visible as candidates, but don't pretend profit is known.
            item.update({"fee":0,"shipping":shipping,"profit":None,"margin":None,"score":0})
            scored.append(item)
        else:
            item=calc(item, fee_rate, shipping)
            if item["profit"] >= min_profit and item["margin"] >= min_margin:
                scored.append(item)
    scored.sort(key=lambda x: (x["profit"] if x["profit"] is not None else -1), reverse=True)
    return {"items":scored[:20], "note":"利益計算は販売価格・手数料・送料を実際の条件に合わせて再確認してください。"}

@app.get("/manifest.webmanifest")
async def manifest():
    return FileResponse("app/static/manifest.webmanifest", media_type="application/manifest+json")

@app.get("/health")
async def health():
    return {"ok":True}
